

var MainGameLayer = cc.Layer.extend({
    Objs: {
        hook: null,
        bg_layer: []
    },
    xRotation: 0,
    currentDirection: 0,
    maxRotationX: 45,
    rotationSpeed: 0.5,
    ctor: function () {
        this._super();



        //Create Hook
        this.Objs.hook = new cc.Sprite(res.hook);
        this.Objs.hook.setPosition(cc.winSize.width / 2, cc.winSize.height / 2 + 100);
        this.Objs.hook.setAnchorPoint(0.5, 1);
        this.Objs.hook.setRotation(0);

        this.createBackground();

        this.xRotation = this.Objs.hook.getRotationX();
        this.currentDirection = -1;

        this.addChild(this.Objs.hook, 1);
        this.drop();

        let something = this;
//this Problem
        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            onKeyPressed: function (k, e) {
                if (k == cc.KEY.space)
                {
                    something.drop();
                }
            }
        }, this);

        this.scheduleUpdate();
   },
    update: function(dt) {
        this.swing();

    },
    createBackground: function() {

    },
    swing: function() {
        if (this.Objs.hook.getRotationX() <= -this.maxRotationX || this.Objs.hook.getRotationX() >= this.maxRotationX) {
            this.currentDirection = -this.currentDirection;
        }

        this.xRotation += this.currentDirection * this.rotationSpeed;
        this.Objs.hook.setRotation(this.xRotation);
    },
    drop: function() {
        console.log("Dropped");
    },
    onKeyPressed(keyCode, event) {
        if (keyCode == cc.KEY.space)
        {
            this.drop();
        }
    }
});

var MainGameScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new MainGameLayer();
        this.addChild(layer);
    }
});
